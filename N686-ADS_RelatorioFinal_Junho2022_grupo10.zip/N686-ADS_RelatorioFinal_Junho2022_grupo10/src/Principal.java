public class Principal {
    public static void main(String[] args) {

        System.out.println("Seja bem-vindo!");
        Menu menu = new Menu();
        menu.apresentarOpcoes();
        System.out.println("Tenha um excelente dia!!!");

    }

}